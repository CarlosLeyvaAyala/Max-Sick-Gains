[![made-with-lazarus](https://img.shields.io/badge/Made%20with-Lazarus-1f425f.svg)](https://www.lazarus-ide.org/)

# About

This is a simple app to rename textures created from the bundled [Photoshop action][].

It's not too complicated. It just checks if a file ends with some number and then it renames it according to user input. \
If no number was found, it renames it using user input and the file timestamp.


# Build dependencies
- [Lazarus IDE][]

[Lazarus IDE]: https://www.lazarus-ide.org/
[Photoshop action]: ../../Skyrim%20Texture%20Manipulation.atn
